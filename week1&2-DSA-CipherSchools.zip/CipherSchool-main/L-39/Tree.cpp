class Node {
public:
	int data;
	Node* left;
	Node* right;
	Node(int val){
		left = NULL;
		right = NULL;
	}
};